package pp.ampel;

import java.util.Random;

final class AmpelSteuerung extends Thread
{

    // Referenz von Ampel
    private final Ampel[] ampeln;

    // private final long intervall;

    // Konstruktor
    public AmpelSteuerung(final Ampel[] ampeln) // , final long intervall
    {
        // super("Steuerung");
        // this.intervall = intervall;
        this.ampeln = ampeln;
    }

    @Override
    public void run()
    {
        final Random random = new Random();
        while (!this.isInterrupted())
        {
            this.ampeln[random.nextInt(this.ampeln.length)].umschalten();
            // Thread.sleep(this.intervall);
        }
    }

    public static void main(final String[] args) throws InterruptedException
    {
        final Random random = new Random();
        final Ampel[] ampeln = new Ampel[5];
        final Auto[] autos = new Auto[5];

        System.err.printf("### Ampeln%n");
        for (int i = 0; i < ampeln.length; i++)
        {
            ampeln[i] = new ItalienischeAmpel("Italienische Ampel #" + i);
            ampeln[i] = new DeutscheAmpel("Deutsche Ampel #" + i);

        }

        System.err.printf("\n\n### Auto%n");
        for (int i = 0; i < autos.length; i++)
        {
            autos[i] = new Auto(ampeln, random.nextInt(ampeln.length), "Auto #" + i);
            autos[i].start();
        }
        Thread.sleep(2 * 1000);

        System.err.printf("\n\n### Steuerung%n");
        final AmpelSteuerung steuerung = new AmpelSteuerung(ampeln); // ,1000
        steuerung.start();
        Thread.sleep(20 * 1000);

        System.err.printf("\n\n### ENDE %n");
        steuerung.interrupt();
        steuerung.join();
        for (final Auto auto : autos)
        {
            auto.interrupt();
            auto.join();
        }
    }
}