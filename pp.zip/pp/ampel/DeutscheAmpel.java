package pp.ampel;

public final class DeutscheAmpel implements Ampel
{
    private boolean gruen;
    private boolean rot;
    private int next = 0;
    private int naechsteWartenummer = 0;
    private int wartendeAutos = 0;
    private int laufendeNummer = 0;

    public static enum AmpelPhase

    {
        ROT, GRUEN;
    }

    private final String name;

    private AmpelPhase phase;

    public DeutscheAmpel()
    {
        this("DeutscheAmpel");
    }

    public DeutscheAmpel(final String name)
    {
        this.name = name;
        this.phase = AmpelPhase.ROT;
    }

    public synchronized void schalteRot()
    {
        this.schalte(AmpelPhase.ROT);
        this.rot = true;
    }

    public synchronized void schalteGruen()
    {
        this.schalte(AmpelPhase.GRUEN);
        this.gruen = true;
        this.notifyAll();
    }

    public synchronized void umschalten()
    {
        switch (this.phase)
        {
        case GRUEN:
            this.schalteRot();
            break;
        case ROT:
            this.schalteGruen();
            break;
        default:
            throw new IllegalStateException();
        }
    }

    private synchronized void schalte(final AmpelPhase newPhase)
    {
        if (this.phase != newPhase)
        {
            this.phase = newPhase;
            System.err.printf("%s schaltet auf %s%n", this.name, this.phase.name());
        }
    }

    public synchronized int wartendeFahrzeuge()
    {
        {
            wartendeAutos = naechsteWartenummer - next;
        }
        notifyAll();
        return wartendeAutos;
    }

    public synchronized void passieren() throws InterruptedException
    {
        // Nächste Wartende Fahrzeuge
        int laufendeNummer = naechsteWartenummer++;
        while (next != laufendeNummer || rot && !gruen)
        {
            try
            {
                wartendeAutos++;
                System.out.println("Auto #" + laufendeNummer + " wartet an Apmel " + this.toString());
                wait();
            }
            catch (InterruptedException e)
            {
                e.printStackTrace();
            }
        }
        next++;
        wartendeAutos--;
        System.out.println("Auto " + laufendeNummer + " passierte Ampel " + this.toString());
        notifyAll();

        while (this.phase == AmpelPhase.ROT)
        {
            this.wait();
        }
    }

    @Override
    public String toString()
    {
        return this.name;
    }
}